$(document).ready(function(){
    $(".img1").click(function(){
        $(this).hide("slow");
    });
});