$(document).ready(function(){
    $('#email').keyup(function(){
        var data = $("#regForm").serialize()   // capture all the data in the form in the variable data
        $.ajax({
            method: "POST",   // we are using a post request here, but this could also be done with a get
            url: "/username",
            data: data
        })
        .done(function(res){
             $('#emailMsg').html(res)  // manipulate the dom when the response comes back
        })
    })

    $('#form1').submit(function(){
        $.ajax({ 
          method: "POST",     // using a GET request would put your form data in the url as query strings
          url: $(this).attr('action'), // 'this' refers to #form1, the element that triggered the function
          data: $(this).serialize()
        })
        .done(function(response) {
          // your code on what to do once the http response is received
        })
        .fail(function(response) {
          // optional code on what to do if the http request fails
        })
        .always(function(data){
          // optional code on what should be done regardless of whether the http request is successful or not
        })
        return false; // return false so the form is not submitted normally
    });

    $('#search').keyup(function(e){
        e.preventDefault();
        var data = $("#searchForm").serialize()
        $.ajax({
            method: "POST",
            url: "/usersearch",
            data: data
        })
        .done(function(res){
             $('#searchRes').html(res)
        })
        return false;
    })
})