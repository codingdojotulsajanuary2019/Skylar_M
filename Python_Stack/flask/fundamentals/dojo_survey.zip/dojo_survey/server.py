from flask import Flask, render_template, request, redirect
app = Flask(__name__)

@app.route('/')
def survey_index():
    return render_template('index.html')

@app.route('/result', methods=['POST'])
def survey_result():
    print('Got Post')
    print(request.form)
    form_name = request.form['name']
    form_loc = request.form['location']
    form_lang = request.form['fav_lang']
    form_com = request.form['comment']
    return render_template('result.html', name_on_temp=form_name, loc_on_temp=form_loc, lang_on_temp=form_lang, com_on_temp=form_com)


if __name__ == "__main__":
    app.run(debug=True)