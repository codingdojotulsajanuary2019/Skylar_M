using System;
using System.Collections.Generic;

namespace Hungry_Ninja
{
    public class Food{
        public string Name;
        public int Calories;
        // Foods can be Spicy and/or Sweet
        public bool IsSpicy; 
        public bool IsSweet; 

        public Food(string name, int cal, bool spicy, bool sweet){
            Name = name;
            Calories = cal;
            IsSpicy = spicy;
            IsSweet = sweet;
        }
    }
    // ////////////////////////////////////////////// //
    public class Buffet{
        public List<Food> Menu;
        
        //constructor
        public Buffet(){
            Menu = new List<Food>(){
                new Food("Tacos", 800, true, false),
                new Food("Sub", 1000, false, false),
                new Food("Hot Wings", 700, true, false),
                new Food("Cake", 450, false, true),
                new Food("Cookie", 250, false, true),
                new Food("Pizza", 600, false, false),
                new Food("Pancakes", 500, false, true),
            };
        }
        
        public Food Serve(){
            Random rand = new Random();
            int Idx = rand.Next(0, Menu.Count);
            return Menu[Idx];
        }
    }
    // /////////////////////////////////////////////// //
    public class Ninja{
        private int calorieIntake;
        public List<Food> FoodHistory;
        
        // add a constructor
        public Ninja(){
            calorieIntake = 0;
            FoodHistory = new List<Food>();
        }
        // add a public "getter" property called "IsFull"
        public bool IsFull{
            get{
                if(calorieIntake >= 1200){
                    return true;
                }
                else{
                    return false;
                }
            }
        }
        // build out the Eat method
        public void Eat(Food item){
            if( IsFull == false){
                calorieIntake += item.Calories;
                FoodHistory.Add(item);
            }
            else{
                Console.WriteLine("This Ninja is full!");
            }
        }
    }
}