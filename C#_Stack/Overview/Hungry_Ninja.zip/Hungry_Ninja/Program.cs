﻿using System;

namespace Hungry_Ninja
{
    class Program
    {
        static void Main(string[] args)
        {
            Buffet NewBuffet = new Buffet();
            Console.WriteLine(NewBuffet);
            Ninja NewNinja = new Ninja();
            while(NewNinja.IsFull == false){
                Food item = NewBuffet.Serve(); 
                Console.WriteLine(item);
                NewNinja.Eat(item);
            }
        }
    }
}
