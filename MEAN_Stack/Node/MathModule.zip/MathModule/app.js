var mathlib = require("./mathlib")();

console.log(mathlib.add(5,3));
console.log(mathlib.multiply(5,3));
console.log(mathlib.square(5));
console.log(mathlib.random(2,16));